[
{
  "model": "app.clients",
  "pk": 1986,
  "fields": {
    "IP_Address": "127.0.0.1",
    "MAC_Address": "00:00:00:00:00:00",
    "Device_Name": null,
    "Time_Left": "00:00:00",
    "Expire_On": "2025-07-30T17:45:55.527Z",
    "Validity_Expires_On": null,
    "Upload_Rate": null,
    "Download_Rate": null,
    "Notification_ID": null,
    "Notified_Flag": false,
    "Date_Created": "2025-07-30T17:20:08.468Z"
  }
},
{
  "model": "app.ledger",
  "pk": 2580,
  "fields": {
    "Date": "2020-11-30T08:32:30.514Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2581,
  "fields": {
    "Date": "2020-11-30T08:32:33.782Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2582,
  "fields": {
    "Date": "2020-11-30T08:32:37.298Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2583,
  "fields": {
    "Date": "2020-11-30T08:32:40.135Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2584,
  "fields": {
    "Date": "2020-11-30T08:32:45.109Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2585,
  "fields": {
    "Date": "2020-11-30T08:32:48.000Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2586,
  "fields": {
    "Date": "2020-11-30T08:33:18.904Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2587,
  "fields": {
    "Date": "2020-11-30T08:33:24.408Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2588,
  "fields": {
    "Date": "2020-11-30T08:33:35.589Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2589,
  "fields": {
    "Date": "2020-11-30T08:33:48.412Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2590,
  "fields": {
    "Date": "2020-11-30T08:35:12.226Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2591,
  "fields": {
    "Date": "2020-11-30T08:35:14.761Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2592,
  "fields": {
    "Date": "2020-11-30T08:35:17.217Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2593,
  "fields": {
    "Date": "2020-11-30T08:35:20.022Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2594,
  "fields": {
    "Date": "2020-11-30T08:35:21.753Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2595,
  "fields": {
    "Date": "2020-11-30T08:35:23.130Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.ledger",
  "pk": 2596,
  "fields": {
    "Date": "2025-07-29T17:16:28.786Z",
    "Client": "00:00:00:00:00:00",
    "Denomination": 10,
    "Slot_No": 1
  }
},
{
  "model": "app.connectiontracker",
  "pk": 1,
  "fields": {
    "Device_MAC": "00:00:00:00:00:00",
    "Connection_IP": "127.0.0.1",
    "Session_ID": "5ddf994a-dab1-427d-ae73-011cc7ac9bda",
    "Connected_At": "2025-07-29T15:07:24.669Z",
    "Last_Activity": "2025-07-29T15:07:24.669Z",
    "Is_Active": false,
    "TTL_Classification": "suspicious",
    "User_Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36"
  }
},
{
  "model": "app.devicefingerprint",
  "pk": 1,
  "fields": {
    "Device_ID": "d174670e5a5d4a2cd8f56316939c393d37ff41f92f28f43b77d273431e173832",
    "User_Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
    "Screen_Resolution": "",
    "Browser_Language": "en-US",
    "Timezone_Offset": null,
    "Platform": "Windows",
    "Default_TTL_Pattern": null,
    "Connection_Behavior": {},
    "First_Seen": "2025-07-29T06:29:38.331Z",
    "Last_Seen": "2025-07-30T19:52:45.387Z",
    "Device_Status": "active",
    "Known_MACs": [
      "00:00:00:00:00:00"
    ],
    "Current_MAC": "00:00:00:00:00:00",
    "MAC_Randomization_Detected": false,
    "Total_TTL_Violations": 1133,
    "Total_Connection_Violations": 0,
    "Last_Violation_Date": "2025-07-30T19:52:45.374Z",
    "Device_Name_Hint": null,
    "Admin_Notes": null
  }
},
{
  "model": "app.devicefingerprint",
  "pk": 2,
  "fields": {
    "Device_ID": "338c0fe100582a0e06c90ab9d7aeaa1a6ecde40a356e9cd643fd841dbd3cdf39",
    "User_Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36",
    "Screen_Resolution": "",
    "Browser_Language": "en-US",
    "Timezone_Offset": null,
    "Platform": "Android",
    "Default_TTL_Pattern": null,
    "Connection_Behavior": {},
    "First_Seen": "2025-07-29T12:00:24.438Z",
    "Last_Seen": "2025-07-30T18:30:37.423Z",
    "Device_Status": "active",
    "Known_MACs": [
      "00:00:00:00:00:00"
    ],
    "Current_MAC": "00:00:00:00:00:00",
    "MAC_Randomization_Detected": false,
    "Total_TTL_Violations": 755,
    "Total_Connection_Violations": 0,
    "Last_Violation_Date": "2025-07-30T18:30:37.414Z",
    "Device_Name_Hint": null,
    "Admin_Notes": null
  }
}
]
