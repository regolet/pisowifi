[
{
  "model": "app.settings",
  "pk": 1,
  "fields": {
    "Hotspot_Name": "REGZPRO WIFI",
    "Hotspot_Address": "Davao Occidental",
    "BG_Image": "1/ml_EsmybeO.jpg",
    "Slot_Timeout": 30,
    "Rate_Type": "manual",
    "Base_Value": "00:10:00",
    "Inactive_Timeout": 60,
    "Redir_Url": null,
    "Vouchers_Flg": 1,
    "Pause_Resume_Flg": 1,
    "Disable_Pause_Time": "00:00:00",
    "Default_Block_Duration": "12:00:00",
    "Enable_Permanent_Block": false,
    "Coinslot_Pin": 7,
    "Light_Pin": 5
  }
},
{
  "model": "app.network",
  "pk": 1,
  "fields": {
    "Server_IP": "10.0.0.1",
    "Netmask": "255.255.255.0",
    "DNS_1": "8.8.8.8",
    "DNS_2": "8.8.4.4",
    "Upload_Rate": null,
    "Download_Rate": null
  }
},
{
  "model": "app.rates",
  "pk": 1,
  "fields": {
    "Denom": 1,
    "Pulse": 1,
    "Minutes": "00:06:00",
    "Validity_Days": 0,
    "Validity_Hours": 0
  }
},
{
  "model": "app.rates",
  "pk": 2,
  "fields": {
    "Denom": 5,
    "Pulse": 5,
    "Minutes": "00:30:00",
    "Validity_Days": 0,
    "Validity_Hours": 0
  }
},
{
  "model": "app.rates",
  "pk": 3,
  "fields": {
    "Denom": 10,
    "Pulse": 10,
    "Minutes": "01:20:00",
    "Validity_Days": 0,
    "Validity_Hours": 0
  }
},
{
  "model": "app.device",
  "pk": 1,
  "fields": {
    "Device_ID": "PERSONAL_USE_ACTIVATED",
    "Ethernet_MAC": "02:81:98:ea:a8:87",
    "Device_SN": "02c0018198eaa887",
    "pub_rsa": "-----BEGIN RSA PUBLIC KEY-----\nMEgCQQCJqIMjp3mEczXuFyT/CsdjV8W0bYXyaF8+UaVAsZgh/irbfsVReyDl3/HJ\nGf/7EyTI9QWebisPLqQ5ojQkvKPdAgMBAAE=\n-----END RSA PUBLIC KEY-----\n",
    "ca": "36iAje4ejGMnu7PXjixA4J40j0AP5EvK68cp7guxoIQ=",
    "action": 1,
    "Sync_Time": "2020-10-10T21:20:16.706Z"
  }
},
{
  "model": "app.securitysettings",
  "pk": 1,
  "fields": {
    "TTL_Detection_Enabled": true,
    "Default_TTL_Value": 64,
    "TTL_Tolerance": 2,
    "Limit_Connections": true,
    "Normal_Device_Connections": 3,
    "Suspicious_Device_Connections": 1,
    "Max_TTL_Violations": 3,
    "Enable_TTL_Modification": false,
    "TTL_Modification_After_Violations": 10,
    "Modified_TTL_Value": 1,
    "TTL_Rule_Duration": "02:00:00",
    "Enable_Device_Blocking": false,
    "Block_Duration": "01:00:00"
  }
},
{
  "model": "app.updatesettings",
  "pk": 1,
  "fields": {
    "GitHub_Repository": "regolet/pisowifi",
    "Check_Interval_Hours": 24,
    "Auto_Download": true,
    "Auto_Install": true,
    "Backup_Before_Update": true,
    "Max_Backup_Count": 3,
    "Last_Check": "2025-07-30T11:12:07.475Z",
    "Current_Version": "2.0.1",
    "Update_Channel": "stable"
  }
},
{
  "model": "app.backupsettings",
  "pk": 1,
  "fields": {
    "Auto_Backup_Enabled": true,
    "Auto_Backup_Interval_Hours": 24,
    "Max_Backup_Count": 10,
    "Backup_Location": "backups/database/",
    "Include_Client_Data": true,
    "Include_System_Settings": true,
    "Include_Logs": false,
    "Compress_Backups": true,
    "Retention_Days": 30,
    "Email_Notifications": false,
    "Email_Recipients": "",
    "Last_Auto_Backup": null
  }
}
]
